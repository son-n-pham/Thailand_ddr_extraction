# Summary
- Re-create a new fresh version without console
- update main_app in main.py
  - Remove console
  - Set this main_app function as the central to call other functions


# Installation:
- Copy the zip file.
- upzip the zip file into folder: C:\development
- copy scripts files into the folder
- run pip install -r requirements.txt
- run Create_shortcut_to_run_Python_script.ps1 in PowerShell_Scripts folder
- windows+R: shell:startup
- copy DDR_Extraction shortcut in Desktop to the startup folder